// Importable application factory. `pnpm start` launches the Node server entry.
export { createApp } from './server/app.js';
